from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

n = int(input("Enter the value of n for the n-bit function to be used : "))
print("Enter 1 for the constant 0 function")
print("Enter 2 for the constant 1 function")
print("Enter 3 for the balanced function")
choice = int(input("Which function would you like the algorithm to detect (1-3) : "))
if not(choice >= 1 and choice <= 3):
	print("Please choose between 1 and 3")
	exit()

q = QuantumRegister(n + 1)
c = ClassicalRegister(n)
qc = QuantumCircuit(q, c)

def con0_Uf(circuit, qubit):
	circuit.barrier()

	pass

	circuit.barrier()

	# If f(x) = 0 for x = {0,1}^n
	# Then |x| |y| --> |x| |y + 0| ==> |x| |y|

def con1_Uf(circuit, qubit):
	circuit.barrier()

	circuit.x(qubit[n])

	circuit.barrier()

	# If f(x) = 1 for x = {0,1}^n
	# Then |x| |y| --> |x| |y + 1| ==> |x| |~y| ==> NOT(y)

def baln_Uf(circuit, qubit):
	circuit.barrier()

	circuit.cx(qubit[n - 1], qubit[n])

	circuit.barrier()

	# If f(x) is balanced for x = {0,1}^n such that it evaluates to 0 and 1 on alternate inputs
	# Then |x| |y| --> |x| |y + f(x)|
	# Notice that f(x) = 0 whenever the last bit of x is 0 and f(x) is 1 otherwise
	# Therefore |x| |y + f(x)| ==> |x| |y + x[n-1]| ==> CNOT(x[n-1],y)

for i in range(n):
	qc.id(q[i])
qc.x(q[n])
qc.barrier()

print("This is the initial state of the system")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n + 1):
	qc.h(q[i])

print("This is the state of the system just before the first and only evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

if choice == 1:
	con0_Uf(qc, q)
elif choice == 2:
	con1_Uf(qc, q)
elif choice == 3:
	baln_Uf(qc, q)
else:
	pass

print("This is the state of the system after the evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.h(q[i])
qc.barrier()

print("This is the state of the system after all operations")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

print("Now we need to measure the first n qubits")
print("As per the Deutsch-Josza algorithm, if we get all 0s, then the function was a constant function")
print("If even a single qubit's measurement comes out to be 1, then the function was balanced")
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.measure(q[i], c[i])
qc.barrier()

M = execute(qc, M_simulator, shots = 1).result().get_counts(qc)
measure = list(dict(M).keys())[0][::-1]
print("Upon measuring, the values obtained are :", measure)
input("\nPress Enter to continue ...\n")

print(qc.draw())

flag = 0
for i in measure:
	if i == '1':
		flag = 1

if flag == 0:
	print("Thus, all 0s are obtained from measurement, meaning the function was CONSTANT")
else:
	print("Thus, at least a single 1 was obtained, meaning the function was BALANCED")
