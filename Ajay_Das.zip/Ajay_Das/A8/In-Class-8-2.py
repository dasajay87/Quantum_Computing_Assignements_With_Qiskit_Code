from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

n = int(input("Enter the value of n for the n-bit function to be used : "))
secret = input("Enter the secret key that you want the function to incorporate : ")

q = QuantumRegister(n + 1)
c = ClassicalRegister(n)
qc = QuantumCircuit(q, c)

def oracle(circuit, qubit, secret):
	circuit.barrier()

	for i in range(n):
		if secret[i] == '1':
			circuit.cx(qubit[i], qubit[n])

	circuit.barrier()

	# Oracle implements |x| |y| --> |x| |y + f(x)|, where + means <xor>
	# f(x) = x.s mod 2
	# f(x) = x_1.s_1 + x_2.s_2 + ... + x_n.s_n
	# Therefore, |x| |y| --> |x| |y + x_1.s_1 + x_2.s_2 + ... + x_n.s_n|
	# If s_i is 0 for some i, then that term is already zero
	# If s_i is 1 for some i, then x_i needs to be xored with y
	# Hence, applying a cnot with x_i as control (when s_i is 1) and y as the target is correct

for i in range(n):
	qc.id(q[i])
qc.x(q[n])
qc.barrier()

print("This is the initial state of the system")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n + 1):
	qc.h(q[i])

print("This is the state of the system just before the first and only evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

oracle(qc, q, secret)

print("This is the state of the system after the evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.h(q[i])
qc.barrier()

print("This is the state of the system after all operations")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

print("Now we need to measure the first n qubits")
print("As per the Bernstein-Vazirani algorithms, whatever value we measure is indeed the secret key")
print("Hence, we just need to measure now and see the output")
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.measure(q[i], c[i])
qc.barrier()

M = execute(qc, M_simulator, shots = 1).result().get_counts(qc)
measure = list(dict(M).keys())[0][::-1]
print("Upon measuring, the values obtained are :", measure)
input("\nPress Enter to continue ...\n")

print(qc.draw())

if str(secret) != str(measure):
	print("Something is wrong!!")
else:
	print("Thus, the Bernstein-Vazirani algorithm was able to find the secret key :", measure)
