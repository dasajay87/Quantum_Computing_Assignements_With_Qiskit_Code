from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
from qiskit_textbook.tools import simon_oracle
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

print("This program needs a new module called qiskit_textbook")
print("This is not a standard module provided by qiskit")
print("To install this module, run the following command in your qiskit environment")
print("pip install git+https://github.com/qiskit-community/qiskit-textbook.git#subdirectory=qiskit-textbook-src\n")
print("_" * 100)

print("\nIf you want to choose the default values for function size and period as shown in class, then enter 0")
print("If you want to enter your own values for function size and period, then enter 1")
choice = int(input("Default or not (0-1) : "))
if choice == 1:
	n = int(input("\nEnter the value for the n-bit function to be used : "))
	period = int(input("Enter a period of your choice for the Simon oracle as an integer : "))
	while period < 0 or period >= 2 ** n:
		print("The period should be between 0 and 2^n - 1")
		period = int(input("Enter a period of your choice for the Simon oracle as an integer : "))
	period = '0' * (n - len(bin(period)[2:])) + bin(period)[2:]
else:
	n = 3
	period = '101'

print("\nDefault function size is 3 bits while the period of the function is 5 ('101')")

q = QuantumRegister(n * 2)
c = ClassicalRegister(n)
qc_old = QuantumCircuit(q, c)

for i in range(n * 2):
	qc_old.id(q[i])
qc_old.barrier()

print("\nThis is the initial state of the system")
print(mq.waveform(qc_old)[1])
print(qc_old.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc_old.h(q[i])
qc_old.barrier()

print("This is the state of the system just before the evaluation of the function")
print(mq.waveform(qc_old)[1])
print(qc_old.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

qc_so = simon_oracle(period)
qc = qc_old & qc_so
qc.barrier()

print("This is the state of the system after the evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.h(q[i])
qc.barrier()

print("This is the state of the system after all operations")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

print("As per the Simon's algorithm, the final state should still be in a superposition of many states")
print("However, we know that, all the states remaining possess the property that y.s = 0")
print("Hence, we need to repeat the experiment approximately n times to get n linearly independent equations which will allow us to solve for s\n")
print("However, we do not know the exact number of times we need to run this algorithm before we get n linearly independent equations")
print("Hence, instead of that, we can simply use qiskit's measurement function and change the number of shots accordingly so that we get all possible linear equations")
input("\nPress Enter to continue ...\n")

print()
print("This is the final circuit diagram")
print(qc.draw())
input("\nPress Enter to continue ...\n")

for i in range(n):
	qc.measure(q[i], c[i])
qc.barrier()

nshots = 256 * 2**n

M = execute(qc, M_simulator, shots = nshots).result().get_counts(qc)
measure_rev = list(dict(M).keys())
measure = []
for i in measure_rev:
	measure.append(i[::-1])
print("Upon measuring, these are the values that we get :", measure)
print("Hence, these are the linear equations that we need to solve\n")
for i in measure:
	count = 0
	for j in range(n):
		if i[j] == '1':
			if count != 0:
				print(" + ", end = '')
			print(f"s{j}", end = '')
			count += 1
	if count == 0:
		print("All zeros, so no equation")
	else:
		print(" = 0")
