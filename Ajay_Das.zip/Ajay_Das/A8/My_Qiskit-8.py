from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np

S_simulator = Aer.backends(name = 'statevector_simulator')[0]

def waveform(quant_circuit):
	job = execute(quant_circuit, S_simulator)
	result = job.result()
	statevector = result.get_statevector()
	n_qubits = int(np.log2(len(statevector)))
	output = ""
	count = 0
	single_ket = ""
	for i in range(2**n_qubits):
		real = np.real(statevector[i])
		imag = np.imag(statevector[i])
		approx_real = np.round(real, decimals = 5)
		approx_imag = np.round(imag, decimals = 5)
		if approx_real !=0 or approx_imag != 0:
			count += 1
			#if int(approx_real) == approx_real:
			#	approx_real = int(approx_real)
			#if int(approx_imag) == int(approx_imag):
			#	approx_imag = int(approx_imag)
			ket = ('0' * (n_qubits - len(bin(i)[2:])) + bin(i)[2:])[::-1]
			single_ket += ket + ' '
			output += f"{approx_real} + {approx_imag} j ==> | {ket} |\n"
	return single_ket, output[:-1]
