from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(2)
qc = QuantumCircuit(q)

print("This file generates |phi_ab| by starting with different valuess and using the same circuit for every value of ab\n")
a, b = list(input("Enter the ab {00, 01, 10, 11} value for |phi_ab| : "))
a = int(a)
b = int(b)

if a == 0 and b == 0:
	qc.id(q[0])
	qc.id(q[1])

elif a == 0 and b == 1:
	qc.id(q[0])
	qc.x(q[1])

elif a == 1 and b == 0:
	qc.x(q[0])
	qc.id(q[1])

elif a == 1 and b == 1:
	qc.x(q[0])
	qc.x(q[1])

else:
	print("Enter a valid value for ab {00, 01, 10, 11}")
	exit()

qc.barrier()
print("\nThis is the initial state needed to generate all possible |phi_ab| using a single circuit")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ... \n")

qc.h(q[0])
qc.h(q[1])
print("State of the system after application of 2 Hadamard gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.z(q[0])
qc.z(q[1])
print("State of the system after application of 2 Sigma-Z gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.cz(q[0], q[1])
print("State of the system after application of the controlled Sigma-Z gate")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.h(q[0])
qc.h(q[1])
qc.barrier()
print("State of the system after application of the final 2 Hadamard gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

print(f"Thus, we have generated |phi_{a}{b}| using a single circuit but with different intial values")
