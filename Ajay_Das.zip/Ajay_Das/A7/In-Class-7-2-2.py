from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(2)
c = ClassicalRegister(1)
qc = QuantumCircuit(q, c)

def con0_gate(circuit, qubit):
	circuit.barrier()

	pass

	circuit.barrier()

	# Alternative way to look at it is that if f(x) = 0 for x = 0,1
	# Then |x| |y| --> |x| |y + 0| ==> |x| |y|

	# This is the matrix representation of the constant 0 function
	# [[1,0,0,0],
	#  [0,1,0,0],
	#  [0,0,1,0],
	#  [0,0,0,1]]

def iden_gate(circuit, qubit):
	circuit.barrier()

	circuit.cx(qubit[0], qubit[1])

	circuit.barrier()

	# Alternative way to look at it is that if f(x) = x for x = 0,1
	# Then |x| |y| --> |x| |y + x| ==> CNOT(x,y)

	# This is the matrix representation of the identity function
	# [[1,0,0,0],
	#  [0,1,0,0],
	#  [0,0,0,1],
	#  [0,0,1,0]]

def bitf_gate(circuit, qubit):
	circuit.barrier()

	circuit.id(qubit[0])
	circuit.x(qubit[1])

	circuit.cx(qubit[0], qubit[1])

	circuit.barrier()

	# Alternative way to look at it is that if f(x) = ~x for x = 0,1
	# Then |x| |y| --> |x| |y + ~x| ==> |x| |y + x + 1| ==> |x| |y + 1 + x| ==> |x| |~y + x| ==> NOT(y) followed by CNOT(x,y)

	# This is the matrix representation of the bit-flip function
	# [[0,1,0,0],
	#  [1,0,0,0],
	#  [0,0,1,0],
	#  [0,0,0,1]]

def con1_gate(circuit, qubit):
	circuit.barrier()

	circuit.id(qubit[0])
	circuit.x(qubit[1])

	circuit.barrier()

	# Alternative way to look at it is that if f(x) = 1 for x = 0,1
	# Then |x| |y| --> |x| |y + 1| ==> |x| |~y| ==> NOT(y)

	# This is the matrix representation of the constant 1 function
	# [[0,1,0,0],
	#  [1,0,0,0],
	#  [0,0,0,1],
	#  [0,0,1,0]]

print("Quantum method for finding whether a function is constant or balanced")
print("Involves only one evaluation of the function\n\n")

qc.id(q[0])
qc.x(q[1])

qc.barrier()

qc.h(q[0])
qc.h(q[1])

print("This is the state of the system just before the first and only evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

print("1 ==> Constant 0 function")
print("2 ==> Identity function")
print("3 ==> Bit-Flip function")
print("4 ==> Constant 1 function")
fun = int(input("Choose one of the four functions (1-4) : "))

if fun == 1:
	con0_gate(qc, q)
elif fun == 2:
	iden_gate(qc, q)
elif fun == 3:
	bitf_gate(qc, q)
elif fun == 4:
	con1_gate(qc, q)
else:
	print("Please enter a valid choice for the function")
	exit()

print("\nThis is the state of the system after the evaluation of the function")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

qc.h(q[0])
qc.id(q[1])

print("This is the state of the system after the final operation of the function")
print("If the measurement of the first qubit outputs 0, then the function is constant")
print("If the measurement of the first qubit outputs 1, then the function is balanced")
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ...\n")

qc.measure(q[0], c[0])

M = execute(qc, M_simulator, shots = 1).result().get_counts(qc)
measure = list(dict(M).keys())[0]
print("Upon measurement, the first qubit turns out to be", measure)
if measure == '0':
	print("Therefore the function is constant")
elif measure == '1':
	print("Therefore the function is balanced")
else:
	print("Therefore the function has some mistake")
