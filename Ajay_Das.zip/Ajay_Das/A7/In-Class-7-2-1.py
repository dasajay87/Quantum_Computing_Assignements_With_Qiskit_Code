def constant0(inp):
	out = 0
	return out

def identity(inp):
	out = inp
	return out

def bit_flip(inp):
	out = inp ^ 1
	return out

def constant1(inp):
	out = 1
	return out

def main():
	print("Classical method for finding whether a function is constant or balanced")
	print("Involves two evaluations of the function\n\n")
	print("1 ==> Constant 0 function")
	print("2 ==> Identity function")
	print("3 ==> Bit-Flip function")
	print("4 ==> Constant 1 function")
	fun = int(input("Choose one of the four functions (1-4) : "))

	if fun == 1:
		print("\nFirst evaluation")
		first = constant0(0)
		print("f(0) =", first)
		input()

		print("Second evaluation")
		second = constant0(1)
		print("f(1) =", second)
		input()

		if first == second:
			print("Hence, the function is constant")
		else:
			print("Hence, the function is balanced")
	
	if fun == 2:
		print("\nFirst evaluation")
		first = identity(0)
		print("f(0) =", first)
		input()

		print("Second evaluation")
		second = identity(1)
		print("f(1) =", second)
		input()

		if first == second:
			print("Hence, the function is constant")
		else:
			print("Hence, the function is balanced")

	if fun == 3:
		print("\nFirst evaluation")
		first = bit_flip(0)
		print("f(0) =", first)
		input()

		print("Second evaluation")
		second = bit_flip(1)
		print("f(1) =", second)
		input()

		if first == second:
			print("Hence, the function is constant")
		else:
			print("Hence, the function is balanced")

	if fun == 4:
		print("\nFirst evaluation")
		first = constant1(0)
		print("f(0) =", first)
		input()

		print("Second evaluation")
		second = constant1(1)
		print("f(1) =", second)
		input()

		if first == second:
			print("Hence, the function is constant")
		else:
			print("Hence, the function is balanced")

main()
