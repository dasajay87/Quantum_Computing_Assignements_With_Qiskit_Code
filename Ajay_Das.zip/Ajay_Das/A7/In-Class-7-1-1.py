from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(2)
qc = QuantumCircuit(q)

print("This file generates |phi_ab| by starting with entangled states and using a different circuit for each value of ab\n")
a, b = list(input("Enter the ab {00, 01, 10, 11} value for |phi_ab| : "))
a = int(a)
b = int(b)

print()
print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
input("\nPress Enter to continue ... \n")

if a == 0 and b == 0:
	qc.h(q[0])
	qc.id(q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cx(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cz(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.id(q[0])
	qc.x(q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.h(q[0])
	qc.id(q[1])

elif a == 0 and b == 1:
	qc.h(q[0])
	qc.id(q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cx(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cz(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.h(q[0])
	qc.id(q[1])

elif a == 1 and b == 0:
	qc.h(q[0])
	qc.id(q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cx(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cz(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.id(q[0])
	qc.h(q[1])

elif a == 1 and b == 1:
	qc.h(q[0])
	qc.id(q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.cx(q[0], q[1])
	print(mq.waveform(qc)[1])
	print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	qc.h(q[0])
	qc.id(q[1])

else:
	print("Enter a valid value for ab {00, 01, 10, 11}")
	exit()

print(mq.waveform(qc)[1])
print(qc.draw())
print("_" * 100)
print(f"The final state can easily be seen to be |phi_{a}{b}|")
