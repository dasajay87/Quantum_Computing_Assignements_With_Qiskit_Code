from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq
import random

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

def Entanglement():
	qA = QuantumRegister(1, name = 'Alice_A')
	qB = QuantumRegister(1, name = 'Bob_B')
	qc = QuantumCircuit(qA)
	qc.add_register(qB)

	qc.h(qA)
	qc.cx(qA,qB)

	qc.barrier()

	_, ent_wave = mq.waveform(qc)
	print("The initial state of the system of entangled bits is")
	print(ent_wave)
	print("\nThus, the entanglement is successful\n")

	return qc, qA, qB

def ALICE(circuit, ebit_A, a, b):
	print("\nState of the system before Alice performs any operation")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	if b == 1:
		circuit.z(ebit_A)
	qc.barrier()
	print("\nState of the system after Alice performs C-sigma-Z with cbit b (instead of a) as control and her qubit A as target")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	if a == 1:
		circuit.x(ebit_A)
	qc.barrier()
	print("\nState of the system after Alice performs C-not with cbit a (instead of b) as control and her qubit A as target")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")
	print("\nAt this point, Alice's work is done and she sends her qubit to Bob")
	input("\nPress Enter to continue ... \n")

	return circuit, ebit_A

def BOB(circuit, ebit_A, ebit_B):
	print("\nState of the system that Bob receives from Alice")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	circuit.cx(ebit_A, ebit_B)
	qc.barrier()
	print("\nState of the system after Bob performs C-not with Alice's qubit A (which Bob now has) as control and Bob's qubit B as target")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	circuit.h(ebit_A)
	qc.barrier()
	print("\nState of the system after Bob performs Hadamard operation on Alice's qubit A (which Bob now has)")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")
	print("\nAs you can see, the two qubit system has now collapsed to the values of a and b that you entered, but in the reverse order as asked in the question (unless you entered an invalid number for a and b)")
	print("Thus, Bob will be able to get the output in the reverse order to what Alice sent him")
	input("\nPress Enter to continue ... \n")

	c = ClassicalRegister(2)
	circuit.add_register(c)

	circuit.measure(ebit_A, c[0])
	circuit.measure(ebit_B, c[1])

	print("\nUpon measuring the state 1024 times, we get the following result")
	print(execute(circuit, M_simulator, shots = 1024).result().get_counts(circuit))
	input("\nPress Enter to continue ... \n")
	print("Note that the output may look opposite but that is only because qiskit reports the values from bottom to top, but I have made sure all my other functions report the values from top to bottom for readability")

def main():
	# Entangling the two qubits using the Entanglement function
	quant_circuit, alice_qubit_A, bob_qubit_B = Entanglement()

	# Taking input for values that Alice sends to Bob
	a = int(input("Enter the value of a that Alice wants to send to Bob (0 or 1) : "))
	if a != 0 and a != 1:
		print("You should have entered 0 or 1, not something else")
		print("As punishment, I will take a random value for a over which you have little to no control")
		a = random.randint(0,1)
	b = int(input("Enter the value of b that Alice wants to send to Bob (0 or 1) : "))
	if b != 0 and b != 1:
		print("You should have entered 0 or 1, not something else")
		print("As punishment, I will take a random value for b over which you have little to no control")

	input("\nPress Enter to continue ... \n")

	# ALICE function does the work that Alice does
	quant_circuit, alice_qubit_A = ALICE(quant_circuit, alice_qubit_A, a, b)

	# BOB function does the work that Bob does
	BOB(quant_circuit, alice_qubit_A, bob_qubit_B)

	# Can be noted that the only communication between Alice and Bob is a single qubit, which is 'alice_qubit_A'
	print("\nThus, by simply sending a single qubit to Bob, Alice was able to send two classical bits of information to Bob and Bob was able to see them in reverse order. Thus, a small change in the superdense coding protocol allows us to reverse the output received by Bob")

main()
