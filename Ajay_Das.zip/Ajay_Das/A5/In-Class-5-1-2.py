from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(5)
qc = QuantumCircuit(q)

x = int(input("Enter the value for x (first control qubit for CCC-NOT) : "))
y = int(input("Enter the value for y (second control qubit for CCC-NOT) : "))
z = int(input("Enter the value for z (third control qubit for CCC-NOT) : "))
w = int(input("Enter the value for w (initial value for target qubit) : "))

if x == 1:
	qc.x(q[0])
if y == 1:
	qc.x(q[1])
if z == 1:
	qc.x(q[3])
if w == 1:
	qc.x(q[4])

qc.barrier()

qc.ccx(q[0], q[1], q[2])
qc.ccx(q[2], q[3], q[4])

_, state = mq.waveform(qc)
print("\nAfter CCC-NOT using 2 Toffoli gates, the output is as follows")
print("x remains x at first qubit position")
print("y remains y at second qubit position")
print("0 is input at third qubit position but output is x ^ y as per the CC-NOT operation")
print("z remains z at fourth qubit position")
print("w is input at fifth qubit position and the output is w <xor> x ^ y ^ z as per the CCC-NOT operation\n")
print(state)
print("____________________________________________________________________________________")

print(qc.draw())
