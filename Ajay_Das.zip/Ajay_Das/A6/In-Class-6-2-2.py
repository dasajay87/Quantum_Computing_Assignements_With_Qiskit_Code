from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq
import random

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

def InitTransportQubit():
	print("1 ==> State will be |0|\n2 ==> State will be |1|")
	print("3 ==> State will be |+| = H|0|\n4 ==> State will be |-| = H|1|")
	print("5 ==> Choose the state yourself")
	ini = int(input("Enter a choice for the state of qubit which Alice wants to send (1-5) : "))

	qT = QuantumRegister(1, name = 'A -> B')
	qc = QuantumCircuit(qT)

	if ini == 1:
		pass
	elif ini == 2:
		qc.x(qT[0])
	elif ini == 3:
		qc.h(qT[0])
	elif ini == 4:
		qc.x(qT[0])
		qc.h(qT[0])
	elif ini == 5:
		a = float(input("Enter the value of a, value of b will be automatically chosen : "))
		b = m.sqrt(1 - a**2)
		qc.initialize([a, b], qT[0])
	else:
		print("Automatic choice of 1 has been made")

	print("_" * 100)
	print("\nTherefore, the initial state is as follows: ")
	init_state = mq.waveform(qc)[1]
	print(init_state)
	if ini != 1:
		print(qc.draw())
	print("_" * 100)
	input("\nPress Enter to continue ... \n")

	# init_state is returned only for printing purposes, it is not required for the protocol
	return qT, qc, init_state

def Entanglement(circuit):
	qA = QuantumRegister(1, name = 'Alice_A')
	qB = QuantumRegister(1, name = 'Bob_B')
	circuit.add_register(qA)
	circuit.add_register(qB)

	circuit.barrier()

	circuit.h(qA)
	circuit.id(qB)
	circuit.cx(qA,qB)

	print("\nThe initial state of the system of entangled bits is")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	print("\nThus, the entanglement of qubit 2 and qubit 3 is successful\n")
	input("\nPress Enter to continue ... \n")

	return circuit, qA, qB

# There is a small issue in doing quantum teleportation using qiskit. The issue arises when Alice's
# operations are done and she needs to measure the qubits. This translates to one execution of the
# quantum circuit where the measured values are saved.
# Now Bob needs these measured values to execute his operations. Hence, the execution needs to
# happen immediately after Alice's measurement. But once Bob is done, in order to show the final
# statevector of the circuit, another execution is invariably required. However, during this
# execution, the measured values could change leading to a different statevector after measurement,
# thereby leading to a different output of the protocol.
# So, we can afford to make only one execution of the circuit after any measurement is made in the
# circuit. Since the final statevector needs to be shown, the execution certainly needs to happen
# at the end. However, if an execution isn't done before Bob's operations, there is no way to know
# what operations Bob must apply.
# Hence, this is an issue, but luckily Qiskit provides a mechanism by which Bob's operations can be
# conditioned on the basis of the measurement of a qubit thereby giving us an in-circuit method to
# either apply or not apply a quantum gate. However, this still doesn't allow us to execute the
# circuit more than once after a measurement operation is done.

# However, if the code is written in such a way that Alice's operations and Bob's operations are
# written in different functions, then still a small trick is needed which isn't exactly correct
# but is something that is needed in order to show the correct working of the quantum teleportation
# protocol in Qiskit. But if the code is written without such explicit functions then this trick is
# not needed. I have implemented in two files, one with the trick and the other without explicit
# functions for Alice and Bob.

##### This file implements without the explicit functions for Alice and Bob #####

def ALICEnBOB(circuit, teleport_qubit, ebit_A, ebit_B, init_state):
	circuit.barrier()

	print("\nState of the system before Alice performs any operation")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	circuit.cx(teleport_qubit, ebit_A)
	print("\nState of the system after Alice performs C-NOT with teleport qubit as control and her entangled qubit A as target")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	circuit.h(teleport_qubit)
	circuit.id(ebit_A)
	print("\nState of the system after Alice performs Hadamard operation on teleport qubit")
	print(mq.waveform(circuit)[1])
	print(circuit.draw())
	input("\nPress Enter to continue ... \n")

	c = ClassicalRegister(3)
	circuit.add_register(c)

	circuit.measure(teleport_qubit, c[0])
	circuit.measure(ebit_A, c[1])

	circuit.barrier()

	print(circuit.draw())
	print("Alice now measures her 2 qubits and sends the value to Bob")
	input("\nPress Enter to continue ... \n")

	circuit.x(ebit_B).c_if(c[1], 1)
	circuit.z(ebit_B).c_if(c[0], 1)

	print(circuit.draw())
	print("Bob performs the C-not operation and the C-sigma-Z operation depending on the value of the measurements")
	input("\nPress Enter to continue ... \n")

	print("_" * 100)
	print("The final state of the system after Bob's operations is as follows:")
	print(mq.waveform(circuit)[1])
	print("_" * 100)
	print("The initial state was as follows:")
	print(init_state)
	print("_" * 100)

	print("Thus, we can see that the teleport qubit (its superposition) has been teleported from Alice to Bob (ignore the initial 2 qubits in the final state) (Bob's entangled qubit now has the same superposition)")

def main():
	print("This file implements without the explicit functions for Alice and Bob.\nFor more details, see the comments in the code\n")
	qT, qc, init_state = InitTransportQubit()
	qc, qA, qB = Entanglement(qc)
	ALICEnBOB(qc, qT, qA, qB, init_state)

main()
