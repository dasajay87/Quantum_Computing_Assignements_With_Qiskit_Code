from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(3)
qc = QuantumCircuit(q)

x = int(input("Enter the value of x (for x ^ y) : "))
y = int(input("Enter the value of y (for x ^ y) : "))

if x == 1:
	qc.x(q[0])
if y == 1:
	qc.x(q[1])

qc.cswap(q[0],q[1],q[2])

_, state = mq.waveform(qc)
print("\nx remains x at first qubit position")
print("y is input at second qubit position and the output is | ~x ^ y > (either 0 or y)")
print("0 is input at third qubit position and the output is | x ^ y >")
print("Therefore x ^ y is given by the output at third qubit\n")
print(state)
ket = state.split()[6][2]
print("Thus, x ^ y = ", ket)
print("____________________________________________________________________________________")

print(qc.draw())
