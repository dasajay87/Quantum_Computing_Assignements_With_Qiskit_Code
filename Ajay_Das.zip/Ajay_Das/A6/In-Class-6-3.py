from qiskit import QuantumRegister, ClassicalRegister, QuantumCircuit, assemble, Aer, execute
import numpy as np
import math as m
import My_Qiskit as mq

S_simulator = Aer.backends(name = 'statevector_simulator')[0]
M_simulator = Aer.backends(name = 'qasm_simulator')[0]

q = QuantumRegister(2)
qc = QuantumCircuit(q)

a, b = list(input("Enter ab {00,01,10,11} for which you want to check U|phi_ab| = |ab| : "))
a = int(a)
b = int(b)

if a == 0 and b == 0:
	qc.h(q[0])
	qc.id(q[1])

	qc.cx(q[0], q[1])
	qc.cz(q[0], q[1])
	qc.x(q[1])

	qc.h(q[0])
	qc.id(q[1])

elif a == 0 and b == 1:
	qc.h(q[0])
	qc.id(q[1])

	qc.cx(q[0], q[1])
	qc.cz(q[0], q[1])

	qc.h(q[0])
	qc.id(q[1])

elif a == 1 and b == 0:
	qc.h(q[0])
	qc.id(q[1])

	qc.cx(q[0], q[1])
	qc.cz(q[0], q[1])

	qc.id(q[0])
	qc.h(q[1])

elif a == 1 and b == 1:
	qc.h(q[0])
	qc.id(q[1])

	qc.cx(q[0], q[1])

	qc.h(q[0])
	qc.id(q[1])

else:
	print("Enter a valid value for ab {00, 01, 10, 11}")
	exit()

print("For this choice of ab, the initialization of |phi_ab| is done as shown in the circuit below")
print(qc.draw())
input("\nPress Enter to continue ... \n")

print("State of the system before applying the circuit")
qc.barrier()
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.h(q[0])
qc.h(q[1])
print("State of the system after application of 2 Hadamard gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.z(q[0])
qc.z(q[1])
print("State of the system after application of 2 Sigma-Z gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.cz(q[0], q[1])
print("State of the system after application of the controlled Sigma-Z gate")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

qc.h(q[0])
qc.h(q[1])
qc.barrier()
print("State of the system after application of the final 2 Hadamard gates")
print(mq.waveform(qc)[1])
print(qc.draw())
input("\nPress Enter to continue ... \n")

print(f"Therefore, the final state after the application of this circuit is simply {a}{b}")
print(f"Thus, this circuit starts with the value |phi_{a}{b}| and returns |{a}{b}|, thus acting as a distinguisher between these 4 functions")
